package 'mysql' do
  action:'install'
end

file '/root/dummy.txt' do
   content 'Resources file'
   action:'create'
end
