def index_exsists?
 ::File.exists?("/var/www/html/index.html")
end

  
