#
# Cookbook:: optum_libraries
# Recipe:: default
#
# Copyright:: 2020, The Authors, All Rights Reserved.

package 'httpd' do
  action :install
end

file '/var/www/html/index.html' do
  content "IP ADDRESS IS  #{node['ipaddress']}"
  action :create
end

execute 'start service' do
  command "service httpd start" 
  only_if { index_exsists? }
end

