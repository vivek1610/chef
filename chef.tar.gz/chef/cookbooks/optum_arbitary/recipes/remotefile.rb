#
# Cookbook:: optum_arbitary
# Recipe:: remotefile
#
# Copyright:: 2020, The Authors, All Rights Reserved.
remote_file '/tmp/prometheus-2.22.0.darwin-amd64.tar.gz' do
   source  'https://github.com/prometheus/prometheus/releases/download/v2.22.0/prometheus-2.22.0.darwin-amd64.tar.gz'
   owner 'root'
   group 'root'
   mode '0755'
   action :create
end

execute 'untar file' do
   command 'tar -xvf /tmp/prometheus-2.22.0.darwin-amd64.tar.gz'
   only_if {File.exist?('/tmp/prometheus-2.22.0.darwin-amd64.tar.gz')}
   cwd '/root/untarfile/'
   action :run
end  
