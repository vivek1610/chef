#
# Cookbook:: optum_databag
# Recipe:: user
#
# Copyright:: 2020, The Authors, All Rights Reserved.
admins = data_bag('admins')
admins.each do |login|
  admin = data_bag_item('admins', login)
    user admin['id'] do
       uid admin['uid']
       shell admin['shell']
    end
end

