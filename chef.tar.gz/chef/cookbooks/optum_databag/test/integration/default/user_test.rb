# InSpec test for recipe optum_databag::user

# The InSpec reference, with examples and extensive documentation, can be
# found at https://www.inspec.io/docs/reference/resources/

['admin1','admin2'].each do |user_name|
  describe user(user_name) do
    it {should exist}
  end
end
