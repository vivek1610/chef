#
# Cookbook:: optum_metadata
# Recipe:: default
#
# Copyright:: 2020, The Authors, All Rights Reserved.

node.default['optum_metadata']['pkg_name'] = 'perl'
package node.default['optum_metadata']['pkg_name'] do
    action :install
end
