#
# Cookbook:: optum_templates
# Recipe:: default
#
# Copyright:: 2020, The Authors, All Rights Reserved.

package 'httpd' do
   action :install
end

package 'tree' do
   action :install
end

template '/var/www/html/index.html' do
   source 'index.html.erb'
   owner 'apache'
   group 'apache'
   mode '0644'
   variables({
      :var1 => node['ipaddress'],
      :var2 => node['fqdn']
   })
   action :create
end 
