#
# Cookbook:: optum_testframework
# Recipe:: websrv
#
# Copyright:: 2020, The Authors, All Rights Reserved.
#include_recipe 'apache2::default'

file '/var/www/html/index.html' do
  content "my Domain Name is #{node['hostnamectl']['static_hostname']}"
  action :create
end
