def index_exists
  execute 'start service' do
    command 'systemctl start httpd'
    only_if { file_exist?('/var/www/html/index.html')}
  end
end

  
