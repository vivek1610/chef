#
# Cookbook:: optum_ngnix
# Recipe:: execute
#
# Copyright:: 2020, The Authors, All Rights Reserved.
execute 'create file' do
   command 'touch /tmp/execute.txt'
   not_if { file_exist?('/tmp/execute.txt')}
end
