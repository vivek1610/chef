#
# Cookbook:: optum_ngnix
# Recipe:: default
#
# Copyright:: 2020, The Authors, All Rights Reserved.
include_recipe 'optum_ngnix::install'
#include_recipe 'optum_ngnix::docroot'
include_recipe 'optum_ngnix::service'
include_recipe 'optum_ngnix::templateresource'
