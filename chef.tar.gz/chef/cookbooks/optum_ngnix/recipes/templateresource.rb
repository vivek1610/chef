#
# Cookbook:: optum_ngnix
# Recipe:: vivek
#
# Copyright:: 2020, The Authors, All Rights Reserved.

template '/var/www/html/index.html' do
   source 'index.html.erb'
   owner 'apache'
   group 'apache'
   mode '0644'
   variables({
      :var1 => 'this is var 1 dynamic value',
      :var2 => 'this is var 2 dynamic value'
   })
   action :create
end
