file '/var/www/html/index.html' do
   content 'Hello World'
   action:create
end
