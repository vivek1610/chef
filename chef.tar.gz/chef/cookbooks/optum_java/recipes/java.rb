#
# Cookbook:: optum_java
# Recipe:: java
#
# Copyright:: 2020, The Authors, All Rights Reserved.
package 'java' do
  action :install
end
