#
# Cookbook:: optum_java
# Recipe:: default
#
# Copyright:: 2020, The Authors, All Rights Reserved.
include_recipe 'optum_java::java'
