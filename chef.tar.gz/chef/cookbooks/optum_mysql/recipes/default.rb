#
# Cookbook:: optum_mysql
# Recipe:: default
#
# Copyright:: 2020, The Authors, All Rights Reserved.
include_recipe 'mysql::default'
