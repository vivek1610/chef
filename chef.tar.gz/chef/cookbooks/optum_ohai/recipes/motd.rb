#
# Cookbook:: optum_ohai
# Recipe:: motd
#
# Copyright:: 2020, The Authors, All Rights Reserved.

file '/etc/motd' do
  content "My ip address is #{node['ipaddress']} and memory is #{node['memory']['total']}"
  action :create
end
