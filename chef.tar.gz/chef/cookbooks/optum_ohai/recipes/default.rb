#
# Cookbook:: optum_ohai
# Recipe:: default
#
# Copyright:: 2020, The Authors, All Rights Reserved.

include_recipe 'optum_ohai::motd'
