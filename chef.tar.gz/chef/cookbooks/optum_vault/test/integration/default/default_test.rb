# InSpec test for recipe optum_vault::default

# The InSpec reference, with examples and extensive documentation, can be
# found at https://www.inspec.io/docs/reference/resources/

describe file '/tmp/password.txt' do
  it { should exist }
end

