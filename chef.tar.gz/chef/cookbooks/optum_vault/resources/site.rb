resource_name :optum_custom
property :homepage,string,default: '<h1>understading custom resources</h1>'

action :create do
  package 'httpd' do
    action :install

  file '/var/www/html/index.html' do
  content new_resource.homepage
  end

  service 'httpd' do
  action [:enable, :start]
  end
end


