#
# Cookbook:: optum_vault
# Recipe:: default
#
# Copyright:: 2020, The Authors, All Rights Reserved.
include_recipe 'chef-vault::default'
secret = chef_vault_item("mysql", "password")

file '/tmp/password.txt' do
  content "password is: #{secret['password']}"
  action :create
end

##custom resouce  
optum_custom 'Custom Resource' do
  homepage 'From Recipe file'
  action :create
end
