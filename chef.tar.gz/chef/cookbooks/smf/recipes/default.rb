## These libraries need to be installed when the cookbook
#  is loaded, otherwise they are not available when the
#  cookbook runs.

chef_gem 'builder'

require 'builder'
