# What for ?
## `files/mysql_pubkey.asc`
This gpgkey is for v3.0.0 and v3.0.1  
Cause those versions refer to the path of gpgkey.
## `files/default/mysql_pubkey.asc`
This gpgkey is for v2.1.0 or lower.  
Because, those versions refer to the path of gpgkey.
